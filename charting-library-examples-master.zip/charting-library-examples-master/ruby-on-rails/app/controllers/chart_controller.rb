class ChartController < ApplicationController
end
