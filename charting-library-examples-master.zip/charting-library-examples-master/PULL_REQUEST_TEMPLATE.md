#### Add example checklist

- [ ] **Any** commit does not contain the charting library's code
- [ ] Addresses an existing issue: #00000
- [ ] The example is added to README.md
- [ ] The example is self-sufficient and contains only necessary files/changes

#### Bug fix checklist

- [ ] **Any** commit does not contain the charting library's code
- [ ] Addresses an existing issue: #00000
