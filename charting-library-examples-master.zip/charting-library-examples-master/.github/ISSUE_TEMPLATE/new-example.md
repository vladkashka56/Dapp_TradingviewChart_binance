---
name: New example
about: Suggest a new example

---

- **Framework/library:** <!-- React, Angular, Vue.js, etc -->
- **Link to page with the framework/library:** <!-- https://vuejs.org/ -->
